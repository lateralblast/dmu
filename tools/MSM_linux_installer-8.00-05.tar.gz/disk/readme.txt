MegaRAID Storage Manager(MSM) Installation
==========================================

The kit contains both mode of installation. The interactive and non-interactive.
To, install the product using interactive mode, the user should execute the command "./install.sh" from the installation disk.
To, install the product in a non-interactive or silent mode, the user may use the command "./install.sh [-options] [ -ru popup]" from the installation disk. The options are:
  a, for Complete installation
  c, for Client Component Only
  s, for StandAlone
The "-ru popup" will remove popup from installation list.
User may also run non-interactive installation using "RunRPM.sh" command.

The installer provides the user with three types of setup option.
1. Complete - This will install all the features of the product.
2. Client Components Only - The storelib feature of the product will not be installed in this type of installation. As a result, the resident system will only be able to administer and configure all the servers in the subnet, but will not be able to serve as a server.
3. StandAlone - Only the networking feature will not be installed in this case. So, the resident system will not be a part of network. In other words, the system will not be able to browse any other MSM servers in the subnet, nor, any one will recognize it as a server.

The installation will help the user to select any of the setup type, but if the user directly run "RunRPM.sh", it will install the complete feature.

NOTE:
	1. For RHEL 5, it is necessary to install compat-libstdc++ version 33-3.x before installing rpm.
	2. For SLES-10 SP3 64bit OS, it is necessary to install libstdc++33-32bit-3.3.3-7.8.1.x86_64.rpm 
	   before installing MSM. This RPM is available in the OS DVD 
	   (path is /media/SUSE-Linux-Enterprise-Server_001/suse/x86_64)
	3. For SLES-9 33bit OS, it is necessary to install compat-libstdc++-lsb-4.0.2_20050901-0.4.i586.rpm
	   before installing MSM. This RPM is available in the OS DVD (path is /media/dvd/suse/i586)
	4. For RHEL 3, it is necessary to install the RPM libstdc++34-3.4.0-1.i386 before installing MSM.


Prerequisite for MSM installation:
==================================
MSM installation scripts also installs the LSI SNMP agent rpm. 
The LSI SNMP agent application depends upon standard SNMP Utils package. 
Please ensure that the SNMP-Util package is present in the system before
installing MSM. SNMP-Util package includes the rpm.s net-snmp-libs , net-snmp-utils  and
additional dependent RPM.s. Please make sure that these RPM.s are installed from the OS media before
installing the MSM.

Prerequisites to run MSM remote admin
======================================

1. Configure the system with valid IP address. Make sure there is no IP address conflict with in the sub network.

2. Ports such as 3071 and 5571 are open and available for MSM framework communication.

3. Disable all security manager and firewall.

4. Configure the multicasting, make sure class D multicast IP addresses are registered (at least 229.111.112.12 should be register for MSM to work), if not create static route using the following command:

        Route add 229.111.112.12 dev eth1.

        Note that this command will not modify the routing table to be persistent across reboots. Please follow the guidelines per operating system to add the above mentioned IP address as a static entry into the routing table to be persistent across reboots.

        You may wish to add the entire range of IP addressess (224.0.0.0 through 239.255.255.255) into the routing table. Please note that this requires procedures that varies between different flavours and versions of operating system and may have security implications.

5. Install MSM, if already installed then restart MSM framework.


CIMPlugin Support
=================
In case of networks that doesn't have DNS configured, the .hosts. file of the systems where MSM is installed must be manually edited to map the IP address & the host name of your CIMOM server.  In addition, it should also have a mapping of its own IP address (not the loop back address) and host name for the indications to be supported.


MSM Uninstallation
==================
The product can be uninstalled using "Uninstall" short-cut created in Program menu. The user may also directly run the script "/usr/local/MegaRAID Storage Manager/uninstaller.sh" to uninstall MSM.


Notes:
  1. MSM upgrade is supported in this release. In other word, this release can be upgraded by future releases.

  2. To shutdown MSM Framework service, run "/etc/init.d/vivaldiframeworkd stop". It is advisable to stop Monitor service before stopping MSM Framework service. To stop Monitor service run "/etc/init.d/mrmonitor stop".
  
  3. "Any kernel upgrade requires restart of the MSM Framework and Services"
      for example, 
      RedHat Linux command to reload or restart network (login as root user):
      To start Linux network service:
      # service network start
      Debian Linux command to reload or restart network:
      # /etc/init.d/networking restart

********************************************************************
    LSI SNMP agent for Linux 
********************************************************************

Installation procedure for LSI SNMP Agent(For SUSE and Red Hat Linux)
--------------------------------------------------------------------------

1. LSI SNMP Agent rpm's installs the agents. 

2. rpm will take care of the necessary modification needed in the snmpd.conf
file for running the agent.
[
NB: Before installation please check,there is any pass command 
    starts with 1.3.6.1.4.1.3582 OID in snmpd.conf, if available then delete
all the old pass commands starts with 1.3.6.1.4.1.3582 OID.
(This could be possible if there is any previous LSI SNMP Agent was installed
in the system)
]
3. The snmpd.conf file structure should be same as lsi_mrdsnmpd.conf. For
reference,a sample conf file (lsi_mrdsnmpd.conf) will be there in the
/etc/lsi_mrdsnmp directory. 

4. For running SNMP query from a remote m/c add the ip address of that m/c in
the snmpd.conf file like this..

   com2sec	snmpclient	172.28.136.112		public

   Here ipaddress of the remote m/c is 172.28.136.112

5. For receiving snmp trap to a particular m/c, add the ip address of that m/c
in the com2sec section of snmpd.conf file. For example, to get Trap in
10.0.0.144, then add following line to snmpd.conf.
#       sec.name	source			community
   com2sec	snmpclient	10.0.0.144		public

6. To Run/stop the snmpd daemon.
   	/etc/init.d/snmpd start/stop
 
7. To start/stop the SNMP Agent daemon before issuing any snmp query.
     /etc/init.d/lsi_mrdsnmpd start/stop

8. Status of the SNMP Agent daemon can be checked by issuing the following
command...
   /etc/init.d/lsi_mrdsnmpd status

9. You can issue snmp query like this...

    snmpwalk -v1 -c public localhost .1.3.6.1.4.1.3582

10. You can get the snmp trap from local m/c by issuing the following
command...
    snmptrapd -P -F "%02.2h:%02.2j TRAP%w.%q from %A %v\n" 


NOTE:
	For SNMP components to work, it is necessary that linux system should
have snmp-net packages(rpm) to be already present.

	It is assumed that snmpd.conf is located at /etc/snmp for Redhat and
/etc for SuSE. Anyway, user can change the file location from
/etc/init.d/lsi_mrdsnmpd file

	It is neccessary to uninstall all the previous version before
installing a new version. The rpm has not been created to support -U version.
The rpm -U is most likely to fail with this rpm.

SNMP Trap Disable functionality
===============================
User may disable SNMP Trap functionality using "-notrap" as install(install.sh) parameter.

MegaRAID Storage Manager(MSM) Installation on VMware :
======================================================
To, install the MSM on VMWare operating system, the user should execute the
command "./vmware_install.sh" from the installation disk.

The installer provides the user to choose the License agreement,operating system 
and storelib to be used as mentioned below.
1. End user license agreement.
2. Operating system  (VMware 3.5 or VMware 4.0).
3. Select the Storelib (Inbox Storelib or Storelib from MSM package).

MegaRAID Storage Manager(MSM) Uninstallation on VMWare :
======================================================
The MSM can be uninstalled by running the script 
"/usr/local/MegaRAID Storage Manager/uninstaller.sh".

Note:
=====
When the user runs the MegaRAID Storage Manager(MSM) installation script
install.sh, the rpm's <Lib_Utils-1.xx-xx.noarch.rpm> and <Lib_Utils2-1.xx-xx.noarch.rpm>
will be installed, These RPM's install the third party libraries and MSM is dependent on these
libraries.If you uninstall the libraries installed by these RPM's then other
applications that are dependent on these libraries may not function correctly. Hence these RPM's
will not be removed when MSM is uninstalled. If you want to remove the RPM,
run the command Rpm -e <Lib_Utils-1.xx-xx.noarch.rpm> and
Rpm -e <Lib_Utils2-1.xx-xx.noarch.rpm>.

If older version of the libutil rpm <Lib_Utils-1.xx-xx.noarch.rpm> is
installed on the system, please uninstall the older version of the RPM using the command "rpm -e
<Lib_Utils-1.xx-xx>" and then install the latest libutil rpm <Lib_Utils-1.xx-xx.noarch.rpm>
packaged in this zip file.

MSM Performance improvement
===========================
For better performance of MSM, when subjected to any heap-intensive (say heavy
IOs) or computational tasks,improve the heap by including the following command
"-Xms1024m -Xmx1024m",where
 1024m           Size of the heap allocated. The specified size is dependent on the machine's Hardware configuration.
 -Xms1024m       Sets the initial size of the Java heap to 1024 Mbytes
 -Xmx1024m       Sets the maximum heap size to 1024 Mbytes

 1. Goto product home folder (/usr/local/MegaRAID Storage Manager).
 2. Open startupui.sh file in editable mode.
 3. Include the command -Xms1024m -Xmx1024m after "./jre/bin/java",
    effectively:
    LD_LIBRARY_PATH=$MSM_HOME/lib ./jre/bin/java -Xms1024m -Xmx1024m -DVENUS=true....
